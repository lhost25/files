<?php


header('Location: verify_new.php');
exit();
?>