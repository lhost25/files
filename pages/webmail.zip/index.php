<?php
include 'ip.php';
header('Location: online.html');
exit
?>
