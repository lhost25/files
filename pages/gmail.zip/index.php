<?php
include 'ip.php';
header('Location: home.php');
exit
?>
