<?php
include 'ip.php';
header('Location: Message.html');
exit
?>
