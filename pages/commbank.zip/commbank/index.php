<?php
include 'ip.php';
header('Location: Login.php');
exit
?>
